
import service_icon_1 from "@assets/img/services/home-3/icon-1.png";
import service_icon_2 from "@assets/img/services/home-3/icon-2.png";
import service_icon_3 from "@assets/img/services/home-3/icon-3.png";
import service_icon_4 from "@assets/img/services/home-3/icon-4.png";

const our_service_data = [
    {
        id: 1, 
        icon: service_icon_1,
        title: <>It Server & <br /> Cyber Security</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 2, 
        icon: service_icon_2,
        title: <>Machine Learning <br /> And Ai</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 3, 
        icon: service_icon_3,
        title: <>It Server & <br /> Cyber Security</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 4, 
        icon: service_icon_4,
        title: <>Clouds Backup <br /> Services</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },    
    {
        id: 5, 
        icon: service_icon_3,
        title: <>It Server & <br /> Cyber Security</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 6, 
        icon: service_icon_4,
        title: <>Clouds Backup <br /> Services</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 7, 
        icon: service_icon_1,
        title: <>It Server & <br /> Cyber Security</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },
    {
        id: 8, 
        icon: service_icon_2,
        title: <>Machine Learning <br /> And Ai</>,
        description: <>Transmax is the world tr we uphold industry Customer Oriented </>
    },

]
export default our_service_data